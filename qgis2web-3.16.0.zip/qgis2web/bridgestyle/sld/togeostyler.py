def convert(geostyler):
    pass  # TODO
